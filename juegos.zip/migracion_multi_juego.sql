-- ============================================================
-- Migración: separar identidad (users) de puntaje (scores),
-- agregar dimensión "game" para soportar múltiples juegos.
--
-- Correr TODO este bloque de una sola vez en el SQL Editor de Supabase.
-- Es transaccional: si algo falla a mitad de camino, no queda nada
-- a medio aplicar.
-- ============================================================

begin;

-- 1. Tablas nuevas -------------------------------------------------

create table public.users (
  name text primary key,
  pin_hash text not null,
  created_at timestamptz not null default now()
);

create table public.scores (
  user_name text not null references public.users(name) on delete cascade,
  -- sumar el id del juego nuevo acá cuando agregues uno (un solo ALTER):
  --   alter table public.scores drop constraint scores_game_check;
  --   alter table public.scores add constraint scores_game_check
  --     check (game in ('nodo','neon-rush','tu-juego-nuevo'));
  game text not null constraint scores_game_check check (game in ('nodo', 'neon-rush')),
  best_score integer not null default 0,
  attempts integer not null default 0,
  updated_at timestamptz not null default now(),
  primary key (user_name, game)
);

-- 2. Migrar datos existentes de NODO --------------------------------

insert into public.users (name, pin_hash, created_at)
select name, pin_hash, updated_at
from public.leaderboard
where pin_hash is not null;

insert into public.scores (user_name, game, best_score, attempts, updated_at)
select name, 'nodo', best_score, attempts, updated_at
from public.leaderboard
where name in (select name from public.users); -- por si hubiera filas viejas sin pin_hash

-- 3. Tabla vieja queda de respaldo, fuera de circulación ------------

alter table public.leaderboard rename to leaderboard_legacy_backup;
revoke all on public.leaderboard_legacy_backup from anon, authenticated;

-- 4. RLS y permisos ---------------------------------------------------

alter table public.users enable row level security;
alter table public.scores enable row level security;

-- users: nadie lee ni escribe directo, todo pasa por las funciones
revoke all on public.users from anon, authenticated;

-- scores: lectura pública igual que antes, escritura solo vía función
grant select (user_name, game, best_score, attempts, updated_at)
  on public.scores to anon, authenticated;

create policy scores_select_public on public.scores for select using (true);

-- 5. Funciones actualizadas ------------------------------------------

drop function if exists public.submit_score(text, text, integer);

create or replace function public.register_or_auth(p_name text, p_pin text)
returns boolean
language plpgsql
security definer
set search_path to 'public', 'extensions'
as $$
declare
  existing record;
begin
  p_name := left(trim(p_name), 14);
  if p_name = '' then
    raise exception 'Nombre inválido';
  end if;
  if p_pin !~ '^[0-9]{4}$' then
    raise exception 'El PIN debe tener exactamente 4 dígitos';
  end if;

  select * into existing from public.users where name = p_name;
  if existing is null then
    insert into public.users (name, pin_hash, created_at)
    values (p_name, crypt(p_pin, gen_salt('bf')), now());
    return true;
  end if;

  if existing.pin_hash is null or existing.pin_hash <> crypt(p_pin, existing.pin_hash) then
    raise exception 'Ese nombre ya está reservado con otro PIN';
  end if;
  return false;
end;
$$;

create or replace function public.submit_score(p_name text, p_pin text, p_game text, p_score integer)
returns void
language plpgsql
security definer
set search_path to 'public', 'extensions'
as $$
declare
  existing_user record;
begin
  p_name := left(trim(p_name), 14);
  if p_game not in ('nodo', 'neon-rush') then
    raise exception 'Juego inválido';
  end if;
  if p_score < 0 or p_score > 200000 then
    raise exception 'Puntaje fuera de rango';
  end if;

  select * into existing_user from public.users where name = p_name;
  if existing_user is null then
    raise exception 'Ese jugador no está registrado';
  end if;
  if existing_user.pin_hash is null or existing_user.pin_hash <> crypt(p_pin, existing_user.pin_hash) then
    raise exception 'PIN incorrecto';
  end if;

  insert into public.scores (user_name, game, best_score, attempts, updated_at)
  values (p_name, p_game, p_score, 1, now())
  on conflict (user_name, game)
  do update set
    best_score = greatest(public.scores.best_score, excluded.best_score),
    attempts   = public.scores.attempts + 1,
    updated_at = now();
end;
$$;

commit;
